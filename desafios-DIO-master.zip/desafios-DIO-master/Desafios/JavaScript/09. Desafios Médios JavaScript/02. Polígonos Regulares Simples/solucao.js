let entrada = gets().split(" ")

console.log(+entrada[0] * +entrada[1])