let T = parseInt(gets());

for (let i = 0; i < T; i++) {
  console.log('Y')
}