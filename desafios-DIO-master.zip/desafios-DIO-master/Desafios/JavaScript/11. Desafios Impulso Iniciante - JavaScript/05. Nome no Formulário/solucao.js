let nome = gets();

console.log(nome.length > 80 ? "NO" : "YES");