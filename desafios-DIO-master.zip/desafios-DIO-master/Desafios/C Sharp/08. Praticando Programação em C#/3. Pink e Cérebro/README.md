<hr />

<h4 align="left">Desafio</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pink e Cérebro dividem um apartamento e estão juntos 24h por dia desde o começo da pandemia. Para passar o temp, Pink cria problemas matemáticos para Cérebro resolver, o último deles foi uma lista de números com a seguinte pergunta: quantos números da lista são múltiplos de 2, 3, 4 e 5?
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Apesar de parecer simples, porém, quando a lista contém muitos números, Cérebro se confunde e acaba errando alguns cálculos.
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ajude Cérebro a resolver o desadio de Pink.
    </p>

<hr />

<h4 align="left">Entrada</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A primeira linha da entrada consiste em um inteiro N (1 ≤ N ≤1000), representando a quantidade de números na lista de Pink.
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A segunda linha contém N inteiros Li (1 ≤ Li ≤ 100), representando os números da lista de Pink.
    </p>

<hr />

<h4 align="left">Saída</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Imprima a quantidade de números múltiplos de 2, 3, 4 e 5 presentes na lista. Observe a formatação da saída nos exemplos, pois ela deve ser seguida rigorosamente.
    <p>

<hr />

<h4 align="left">Solução</h4>
    <p align="left">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://github.com/lucasrmagalhaes/desafios-DIO/blob/master/Desafios/C%20Sharp/8.%20Praticando%20Programa%C3%A7%C3%A3o%20em%20C%23/3.%20Pink%20e%20C%C3%A9rebro/solucao.cs">Código</a>
    </p>

<hr />