<hr />

<h4 align="left">Desafio</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Você terá o desafio de escrever um programa que leia um valor inteiro N (1 < N < 1000). Este N é a quantidade de linhas de saída que serão apresentadas na execução do programa.
    </p>

<hr />

<h4 align="left">Entrada</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;O arquivo de entrada contém um número inteiro positivo N.
    </p>

<hr />

<h4 align="left">Saída</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Imprima a saída conforme o exemplo fornecido.
    <p>

<hr />

<h4 align="left">Solução</h4>
    <p align="left">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://github.com/lucasrmagalhaes/desafios-DIO/blob/master/Desafios/Kotlin/1.%20Introdu%C3%A7%C3%A3o%20a%20programa%C3%A7%C3%A3o%20em%20Kotlin/2.%20N%C3%BAmeros%20%C3%8Dmpares/solucao.kt">Código</a>
    </p>

<hr />