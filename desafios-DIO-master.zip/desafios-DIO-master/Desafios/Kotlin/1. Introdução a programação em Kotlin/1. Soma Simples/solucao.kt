import java.util.Scanner

fun main(args: Array<String>) 
{
    val input = Scanner(System.`in`)
    val a = input.nextInt()
    val b = input.nextInt()

    println("SOMA = " + (a + b)) 
}