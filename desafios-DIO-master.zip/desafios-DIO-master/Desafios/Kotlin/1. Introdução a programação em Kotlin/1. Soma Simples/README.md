<hr />

<h4 align="left">Desafio</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Leia dois valores inteiros identificados como variáveis A e B. Calcule a soma entre elas e chame essa variável de SOMA.
        <br />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;A seguir escreva o valor desta variável.
    </p>

<hr />

<h4 align="left">Entrada</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;O arquivo de entrada contém 2 valores inteiros.
    </p>

<hr />

<h4 align="left">Saída</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Imprima a variável SOMA com todas as letras maiúsculas, inserindo um espaço em branco antes e depois do símbolo de igualdade, seguido pelo valor correspondente à soma de A e B.
    <p>

<hr />

<h4 align="left">Solução</h4>
    <p align="left">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://github.com/lucasrmagalhaes/desafios-DIO/blob/master/Desafios/Kotlin/1.%20Introdu%C3%A7%C3%A3o%20a%20programa%C3%A7%C3%A3o%20em%20Kotlin/1.%20Soma%20Simples/solucao.kt">Código</a>
    </p>

<hr />