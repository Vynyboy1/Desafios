fun main(args: Array<String>) 
{
    for (i in 1.rangeTo(readLine()!!.toInt()).step(2)) println(i)
}