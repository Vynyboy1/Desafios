<hr />

<h4 align="left">Desafio</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Leia um valor inteiro X (1 <= X <= 1000). Em seguida mostre os ímpares de 1 até X, 
        um valor por linha, inclusive o X, se for o caso.
    </p>

<hr />

<h4 align="left">Entrada</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;O arquivo de entrada contém 1 valor inteiro qualquer.
    </p>

<hr />

<h4 align="left">Saída</h4>
    <p align="justify">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Imprima todos os valores ímpares de 1 até X, inclusive X, se for o caso.
    <p>

<hr />

<h4 align="left">Solução</h4>
    <p align="left">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://github.com/lucasrmagalhaes/desafios-DIO/blob/master/Desafios/Kotlin/1.%20Introdu%C3%A7%C3%A3o%20a%20programa%C3%A7%C3%A3o%20em%20Kotlin/2.%20N%C3%BAmeros%20%C3%8Dmpares/solucao.kt">Código</a>
    </p>

<hr />